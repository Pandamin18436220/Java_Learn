# NeuralNetwork and Deep Learning
神经网络和深度学习

### 包结构
    src
    |—— RBM Restricted Boltzmann Machine 限制玻尔兹曼机
    |—— DBN 深层置信网络
    |—— YCD.BPNN BP神经网络
    |—— LvShun.BP github上fork LvShun的神经网络代码
